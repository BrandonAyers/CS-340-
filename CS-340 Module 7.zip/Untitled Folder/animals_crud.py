from pymongo import MongoClient
from bson.objectid import ObjectId
from pprint import pprint


class AnimalShelter:
    """CRUD operations for Animal collection in MongoDB."""

    def __init__(self, username, password):
        """Initialize the MongoDB connection."""
        # Connection Variables
        USER = username
        PASS = password
        HOST = 'nv-desktop-services.apporto.com'
        PORT = 31042
        DB = 'aac'
        COL = 'animals'

        # Initialize Connection
        self.client = MongoClient(f'mongodb://{USER}:{PASS}@{HOST}:{PORT}')
        self.database = self.client[DB]
        self.collection = self.database[COL]

    def create(self, data):
        """Insert a new document into the animals collection."""
        if data is not None:
            self.collection.insert_one(data)  # data should be a dictionary
            return True
        else:
            raise ValueError("Nothing to save, because data parameter is empty.")

    def read(self, searchData):
        """Retrieve documents from the animals collection."""
        if searchData:
            data = self.collection.find(searchData)
        else:
            data = self.collection.find({})
        
        return list(data)  # Return a list of documents

    def update(self, searchData, updateData):
        """Update documents in the animals collection based on query parameters."""
        if searchData is not None:
            result = self.collection.update_many(searchData, {"$set": updateData})
            return result.modified_count
        return 0

    def delete(self, data):
        """Delete documents from the animals collection based on query parameters."""
        if data is not None:
            result = self.collection.delete_many(data)
            return result.deleted_count
        return 0
            